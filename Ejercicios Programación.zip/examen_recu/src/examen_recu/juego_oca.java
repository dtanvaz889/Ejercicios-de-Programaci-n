package examen_recu;

import java.util.Scanner;

public class juego_oca {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int TAMCIRCUITO = 11;
		int fichaJ1 = 0;
		int fichaJ2 = 0;
		int minDado;
		int maxDado;
		int tirada1;
		int tirada2;
		
		Scanner s=new Scanner(System.in);	
		Scanner n=new  Scanner(System.in);

		System.out.println(" ");
		System.out.println("�Bienvenido a la carrera del siglo!");
		System.out.println("-----------------------------------");
		System.out.println(" ");
		
		System.out.println("�Cual es el n�mero m�nimo del dado?");
		System.out.println(" ");
		System.out.print(" > ");
		minDado = n.nextInt();
		System.out.println(" ");
		
		System.out.println("�Cual es el n�mero m�ximo del dado?");
		System.out.println(" ");
		System.out.print(" > ");
		maxDado = n.nextInt();
		System.out.println(" ");
		
		while (minDado>=maxDado) {
			System.out.println("El valor m�ximo del dado no puede ser menor ni igual al valor m�nimo");
			System.out.println(" ");
			System.out.println("�Cual es el n�mero m�ximo del dado?");
			System.out.println(" ");
			System.out.print(" > ");
			maxDado = n.nextInt();
			System.out.println(" ");
		}
		
		System.out.println("�Cual es el nombre del jugador 1?");
		System.out.println(" ");
		System.out.print(" > ");
		String nombreJ1 = s.nextLine();
		String nombre1 = nombreJ1.toLowerCase();
		System.out.println(" ");
		
		System.out.println("�Cual es el nombre del jugador 2?");
		System.out.println(" ");
		System.out.print(" > ");
		String nombreJ2 = s.nextLine();
		String nombre2 = nombreJ2.toLowerCase();
		System.out.println(" ");

	
		while (nombre1.equals(nombre2)) {
			System.out.println("Los nombres del J1 y J2 no pueden ser iguales");
			System.out.println("�Cual es el nombre del jugador 2?");
			System.out.println(" ");
			System.out.print(" > ");
			nombreJ2 = s.nextLine();
			nombre2 = nombreJ2.toLowerCase();
		}
		
		
		System.out.println(" ");
		System.out.println("�COMENCEMOS A JUGAR!");
		System.out.println("--------------------");
		System.out.println(" ");
		
		
		pintaPista(fichaJ1, fichaJ2);

		System.out.println("");
		System.out.println("--------------------------");
		System.out.println("Pulsa ENTER para continuar");
		System.out.println("--------------------------");

		String enter = s.nextLine();
		System.out.println(" ");
		
		System.out.println("Turno del jugador 1 "+ nombreJ1);
		tirada1 = tiraDados(minDado, maxDado);
		tirada2 = tiraDados(minDado, maxDado);
		System.out.println("Ha sacado un "+tirada1+ " en la primera tirada");
		System.out.println("Ha sacado un "+tirada2+ " en la segunda tirada");
		
		
		if (sumaDeNumerosEsPrimo(tirada1, tirada2)==true) {
			
			fichaJ1=tirada1+tirada2;
		}

		s.close();
		n.close();
	}
	
	public static int tiraDados(int minDado, int maxDado) {
		
		int tirada = (int)(Math.random() * (maxDado-minDado+1)+minDado);
		
		return tirada;
	}
	
	public static String pintaPista(int fichaJ1, int fichaJ2) {
		
		System.out.println("\t1\t2\t3\t4\t5\t6\t7\t8\t9\t10\t11");
		
		System.out.println(" ");
		System.out.println("J1");
		System.out.println(" ");
		System.out.println("J2");
		
		
	return null;
	}
	
	public static boolean sumaDeNumerosEsPrimo (int numero1, int numero2) {
		
		int suma;
		boolean esPrimo = true;
		
		suma = numero1+numero2;
		
		for (int i=0; i < suma; i++) {
			
			if ((suma % i) == 0) {
				esPrimo = false;
			}
		}
		return esPrimo;
	}
	
	public static String imprimeComoVaLaCarrera (int nombreJ1, int fichaJ1,int nombreJ2, int fichaJ2) {
	
		
		return null;
	}
	
	public static String EsGanador (int nombreJ1, int fichaJ1, int nombreJ2, int fichaJ2) {
		
		
		return null;
	}

}
