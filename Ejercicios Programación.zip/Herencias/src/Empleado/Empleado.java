package Empleado;

public class Empleado {

	protected String nombre;

	//Constructor por defecto
	public Empleado () {
		
	}
	
	//Constructor con parametros
	public Empleado (String nombre) {
		super();
		
		this.nombre = nombre;
	}
	
	//Constructor copia
	public Empleado (final Empleado c) {
		super();
		
		nombre = c.nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Empleado " + nombre;
	}
	
}