package examen_java;

import java.io.IOException;

public class examen_java_intento {

/*Inicio la matiz del carton*/
   public static int [][] iniciar_matriz_carton(){

  int[][] matriz_carton = new int[3][3];

  for(int i=0; i<3;i++) {

  for(int j=0; j<3; j++) {
  matriz_carton[j][i]=0;
  }

  }

  return matriz_carton;

   }

/*Relleno el carton*/
   public static int[][] rellenar_matriz_carton(){

  int[][] matriz_carton = new int[3][3];

  for(int i=0; i<3;i++) {
 
  for(int j=0; j<3; j++) {

  }

  }

  return matriz_carton;

   }  



/*Imprimo los cartones*/
public static void imprimir_carton(int[][] tablero) {

for(int i=0; i<3;i++) {

for(int j=0; j<3; j++) {

if (tablero[i][j]==-1) {
System.out.print("-");

}else {
System.out.print(tablero[i][j]+"");
}

if (tablero[i][j]<9) {
System.out.print(" ");
}

System.out.print("-");
}

System.out.println("");
}

}


/*Tacho el n�mero que ya ha salido en el carton*/
   public static int[][] tachar_carton(int[][] tablero, int ficha){
   
  int numero_tachado[][] = tablero;
   
   for ( int i = 0; i<3; i++) {
   
            for (int j=0; j<3; j++) {
           
                if (numero_tachado[j][i]==ficha) {
                    numero_tachado[j][i]=-1;
                }
            }
           
        }            
   
       return numero_tachado;
   }    
       
/*Comrpruebo lo que est� tachado con un booleano para que me devuelva un valor de "VERDADERO/FALSO"*/      
   public static boolean comprobar_numero_tachado(int[][] matriz_carton) {
 
  for(int i=0; i<5; i++) {
 
  for(int j=0; j<3; j++) {
 
  if (matriz_carton[j][i]!=-1) {
  return false;
  }
 
  }
 
  }
 
  return true;
   
   }    
   
   
/*Compruebo que las lineas se completan con un booleano para que me devuelva un valor de "VERDADERO/FALSO"*/
   public static boolean comprobar_linea_completa(int[][] matriz_carton) {
 
  boolean linea_completa=true;
 
  for (int i=0; i<3; i++) {
  linea_completa=true;
 
  for(int j=0; j<5; j++) {
               if (matriz_carton[i][j]!=-1) {
  linea_completa=false;
           }
  }
  if (linea_completa) {
  return true;
  }
  }
  return false;
   }
   
   
/*Algoritmo principal del juego*/
   public static void main(String[] args) throws IOException {
       // TODO Auto-generated method stub


       
/*Booleans necesarios*/
       boolean ficha=false;
       boolean fin;

       
       
/*Imprimo el tablero y ejecuto las matrices de los cartones*/
       
       int carton_jugador_1[][];
       int numero_bola;
       
       carton_jugador_1=new int [3][6];
       
       carton_jugador_1=iniciar_matriz_carton();
       
       carton_jugador_1=rellenar_matriz_carton();
       
       System.out.println("�Juguemos al tres en raya!");
		System.out.println("");
		System.out.println("�Te explico las reglas!");
		System.out.println("Tu eres 'o' y yo soy 'x'");
		System.out.println("");
		System.out.println("");
       imprimir_carton(carton_jugador_1);

       System.out.println(" ");
       
       
       int carton_jugador_2[][];
       
       carton_jugador_2= new int [3][6];
       
       carton_jugador_2 = iniciar_matriz_carton();
       
       carton_jugador_2 = rellenar_matriz_carton();
       
       System.out.println("Carton del Jugador 2");
       System.out.println("--------------------");
       
       imprimir_carton(carton_jugador_2);
       
       System.out.println(" ");
       
       
       /*En este bucle se sacan las bolas por pantalla, se tachan los n�meros que han salido y se comprueban la linea y el bingo*/
       do {
           System.out.println(" ");
           System.out.println("Pulsa intro para sacar una bola:");
           
           
           /*Se incluye para que salgan las bolas de 1 en 1*/
           System.in.read();
           System.in.read();

           
           /*Bolas*/
           do {
               numero_bola=(int) (Math.random()*49+1);
               
               bola=false;
               fin=false;
               int i=0;
               
               while( i<50 && !fin) {
             
                   if (numero_bola==matriz_bolas[i]) {
                       fin=true;
                   }
                   
                   if(matriz_bolas[i]==0) {
                       matriz_bolas[i]=numero_bola;
                       fin=true;
                       bola=true;
                       
                   }
                   
                   i++;
                   
               }          
               
           }while(!bola);
            System.out.println("Nueva bola: " + numero_bola);
            System.out.println(" ");
            System.out.println(" ");

           
           /*Se ejecuta "tachar_carton" y se imprimen los cartones*/
           carton_jugador_1=tachar_carton(carton_jugador_1, numero_bola);
           carton_jugador_2=tachar_carton(carton_jugador_2, numero_bola);
           
           System.out.println("Carton del Jugador 1:");
           System.out.println("--------------------");
           
           imprimir_carton(carton_jugador_1);
           
           System.out.println(" ");
           System.out.println("Carton del Jugador 2:");
           System.out.println("--------------------");
           
           imprimir_carton(carton_jugador_2);

           /*Se comprueba SI "numero_tachado" y "linea completa"*/
           if (!comprobar_numero_tachado(carton_jugador_1)) {
         
               if (!linea && comprobar_linea_completa(carton_jugador_1)) {
                   dinero_jugador_1+=100;
                   linea=true;
                   
                   System.out.println(" ");
                   System.out.println("Jugador 1 canta linea");
                   System.out.println(" ");
                   System.out.print("Dinero acumulado Jugador 1:");
                   
                   System.out.println(dinero_jugador_1);
                   
                   System.out.print("Dinero acumulado Jugador 2:");

                   
                   System.out.println(dinero_jugador_2);
                   
               }    
               
           } else {
               System.out.println(" ");
               System.out.println("El Jugador 1 ha cantado Bingo!");
               
               dinero_jugador_1+=500;}
           
           /*Se comprueba SI NO "numero_tachado" y "linea completa"*/
           if (!comprobar_numero_tachado(carton_jugador_2)) {
         
               if (!linea && comprobar_linea_completa(carton_jugador_2)) {
                   dinero_jugador_2+=100;
                   linea=true;
                   
                   System.out.println(" ");
                   System.out.println("Jugador 2 canta linea");
                   System.out.println(" ");
                   System.out.print  ("Dinero acumulado:");
                   
                   System.out.println(dinero_jugador_1);
                   System.out.println(dinero_jugador_2);
                   
               }
               
           } else {
               System.out.println(" ");
               System.out.println("El Jugador 2 ha cantado Bingo!");
               
               dinero_jugador_2+=500;}
           
           } while (!comprobar_numero_tachado(carton_jugador_1) && !comprobar_numero_tachado(carton_jugador_2));
       
          System.out.println(" ");
  System.out.print("Dinero acumulado por el Jugador 1: ");
 
  System.out.println(dinero_jugador_1);
 
  System.out.println(" ");
  System.out.print("Dinero acumulado por el Jugador 2: ");
   }
}
