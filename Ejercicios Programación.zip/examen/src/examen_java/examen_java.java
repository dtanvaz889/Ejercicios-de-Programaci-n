package examen_java;

public class examen_java {
	
	
	private static void crearTablero() {
		for (int i=0; i<9; i++) {
			Object[] tablero = null;
			tablero[i]=Integer.toString(i+1).charAt(0);
		}
	}
	
	private static void imprimeTablero() {
		Object[] tablero = null;

		int i=0;
		
		for(i=0; i<7; i++) {
			switch (i){
				case 0,2,4,6:
					System.out.println("- - - - - - -");
					break;
				
				case 1:
					System.out.println("|"+tablero[0]+tablero[1]+tablero[2]);
					break;
					
				case 3:
					System.out.println("|"+tablero[3]+tablero[4]+tablero[5]);
					break;
					
				case 5:
					System.out.println("|"+tablero[6]+tablero[7]+tablero[8]);
					break;
			}
					
		}
				
	}
	
	public void mueveFichaAleatoria() {
		
	}
	
	public void conviertePosicionMovimiento( ) {
		
	}
	
	public void usuarioMueveFicha() {
		
	}
	
	public void limpiaTablero() {
		Object[] tablero = null;

		for (int i=0; i<9; i++) {
			tablero[i]="";
		}
	}
	
    public void ganaPrograma() {
    
    }
    
    public void ganaUsuario() {
    	
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x1, x2, x3;
		int o1, o2, o3;
		
		System.out.println("�Juguemos al tres en raya!");
		System.out.println("");
		System.out.println("�Te explico las reglas!");
		System.out.println("Tu eres 'o' y yo soy 'x'");
		System.out.println("");
		System.out.println("");
		
		crearTablero();
		imprimeTablero(); 
	}

}
