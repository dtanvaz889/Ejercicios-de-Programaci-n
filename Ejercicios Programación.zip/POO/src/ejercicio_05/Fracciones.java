package ejercicio_05;

public class Fracciones {

}
