package ejercicio_02;

import java.util.Scanner;

public class mein {
	
	public static void main(String[] args) {
	       
		 Scanner sc = new Scanner(System.in);
		 String nombre, numero;
		 double tipo, importe;

		 //se crea objeto cuenta1 sin par�metros
		 //se ejecuta el constructor por defecto
		 Cuenta cuenta_1 = new Cuenta();

		 System.out.print("Nombre : ");
		 nombre = sc.nextLine();
		 System.out.print("N�mero de cuenta : ");
		 numero = sc.nextLine();
		 System.out.print("Tipo de interes : ");
		 tipo = sc.nextDouble();
		 System.out.print("Saldo: ");
		 importe = sc.nextDouble();

		 cuenta_1.setNombre_cliente(nombre);
		 cuenta_1.setNum_cuenta(numero);
		 cuenta_1.setTipo_interes(tipo);
		 cuenta_1.setSaldo(importe);

		 //se crea el objeto cuenta2 con los valores leidos por teclado
		 //se ejecuta el constructor con par�metros
		 Cuenta cuenta_2 = new Cuenta();                       

		 //se crea cuenta3 como copia de cuenta1
		 //se ejecuta el constructor copia
		 Cuenta cuenta_3 = new Cuenta(cuenta_1);

		 //mostrar los datos de cuenta1
		 System.out.println("Datos de la cuenta 1");
		 System.out.println("Nombre del titular: " + cuenta_1.getNombre_cliente());
		 System.out.println("N�mero de cuenta: " + cuenta_1.getNum_cuenta());
		 System.out.println("Tipo de inter�s: " + cuenta_1.getTipo_interes());
		 System.out.println("Saldo: " + cuenta_1.getSaldo());
		 System.out.println("Se ingresan 1000$ en la cuenta");
		 //se realiza un ingreso en cuenta1
		 cuenta_1.ingreso();
		     
		 //mostrar el saldo de cuenta1 despu�s del ingreso
		 System.out.println("Saldo: " + cuenta_1.getSaldo());
		     
		 System.out.println("");
		 
		 //mostrar los datos de cuenta2
		 System.out.println("Datos de la cuenta 2");
		 System.out.println("Nombre del titular: " + cuenta_2.getNombre_cliente());
		 System.out.println("N�mero de cuenta: " + cuenta_2.getNum_cuenta());
		 System.out.println("Tipo de inter�s: " + cuenta_2.getTipo_interes());
		 System.out.println("Saldo: " + cuenta_2.getSaldo());
		 System.out.println();
		     
		 //mostrar los datos de cuenta3
		 System.out.println("Datos de la cuenta 3");
		 System.out.println("Nombre del titular: " + cuenta_3.getNombre_cliente());
		 System.out.println("N�mero de cuenta: " + cuenta_3.getNum_cuenta());                                         
		 System.out.println("Tipo de inter�s: " + cuenta_3.getTipo_interes());
		 System.out.println("Saldo: " + cuenta_3.getSaldo());
		 System.out.println();
		     
		 //realizar una transferencia de 10� desde cuenta3 a cuenta2
		 cuenta_3.transferencia();
		     
		 //mostrar el saldo de cuenta2
		 System.out.println("Saldo de la cuenta 2");
		 System.out.println("Saldo: " + cuenta_2.getSaldo());
		 System.out.println();
		     
		 //mostrar el saldo de cuenta3
		 System.out.println("Saldo de la cuenta 3");
		 System.out.println("Saldo: " + cuenta_3.getSaldo());
		 System.out.println();
		 
			sc.close();
		}
}
