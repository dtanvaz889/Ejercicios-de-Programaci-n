package ejercicio_02;

public class Cuenta {

	private String nombre_cliente;
	private String num_cuenta;
	private double tipo_interes;
	private double saldo;
	
	//constructor
	public Cuenta() {
		nombre_cliente = "Manolo";
		num_cuenta = "1357ODQF135";
		tipo_interes = 5;
		saldo = 8321;
	}
	
	//copia constructor
	public Cuenta(final Cuenta c) {
		nombre_cliente = c.nombre_cliente;
		num_cuenta = c.num_cuenta;
		tipo_interes = c.tipo_interes;
		saldo = c.saldo;
		
	}
	
	//getters y setters
	public String getNum_cuenta() {
		return num_cuenta;
	}

	public void setNum_cuenta(String num_cuenta) {
		this.num_cuenta = num_cuenta;
	}

	public double getTipo_interes() {
		return tipo_interes;
	}

	public void setTipo_interes(double tipo_interes) {
		this.tipo_interes = tipo_interes;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public String getNombre_cliente() {
		return nombre_cliente;
	}

	public void setNombre_cliente(String nombre_cliente) {
		this.nombre_cliente = nombre_cliente;
	}
	
	//metodo ingreso
	public boolean ingreso() {
		boolean ingreso = true;
		if (1000<0) {
			ingreso = false;
		}else {
			saldo = saldo + 1000;
		}
		return ingreso;
	}
	
	//metodo reintegro
	public boolean reintegro () {
		boolean reintegro = true;
		if (1000<0) {
			reintegro = false;
		}else if (saldo>=1000) { 
			saldo -= 1000;
		}else {
			reintegro = false;
		}
		return reintegro;
	}
	
	//metodo transferencia
	public boolean transferencia () {
		boolean correcto = true;
		if (1000<0) {
			correcto = false;
		}else if (saldo>=1000) {
			reintegro ();
			ingreso ();
		}else {
			correcto = false;
		}
		return correcto;
	}
}
