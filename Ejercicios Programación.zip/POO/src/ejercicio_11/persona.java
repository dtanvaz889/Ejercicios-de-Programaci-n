package ejercicio_11;

import ejercicio_04.Libro;

public class persona {
	private String nombre;
	private String direccion;
	private String codigoPostal; 
	private String ciudad; 
	private int fechaNacimiento;
	
	//constructor por defecto
		public persona() {
			
		}
		
		//constructor
		public persona (String nombre, String direccion, String codigoPostal, String ciudad, int fechaNacimiento) {
			this.nombre=nombre;
			this.direccion=direccion;
			this.codigoPostal=codigoPostal;
			this.ciudad=ciudad;
			this.fechaNacimiento=fechaNacimiento;
		}
		
		//constructor copia
		public persona (final persona c) {
			nombre = c.nombre;
			direccion=c.direccion;
			codigoPostal=c.codigoPostal;
			fechaNacimiento=c.fechaNacimiento;
		}

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public String getDireccion() {
			return direccion;
		}

		public void setDireccion(String direccion) {
			this.direccion = direccion;
		}

		public String getCodigoPostal() {
			return codigoPostal;
		}

		public void setCodigoPostal(String codigoPostal) {
			this.codigoPostal = codigoPostal;
		}

		public String getCiudad() {
			return ciudad;
		}

		public void setCiudad(String ciudad) {
			this.ciudad = ciudad;
		}

		public int getFechaNacimiento() {
			return fechaNacimiento;
		}

		public void setFechaNacimiento(int fechaNacimiento) {
			this.fechaNacimiento = fechaNacimiento;
		}
		
		
}
