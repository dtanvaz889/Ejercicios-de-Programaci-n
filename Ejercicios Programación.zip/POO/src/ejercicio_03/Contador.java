package ejercicio_03;

public class Contador {

	
	private double cont;
	
	//constructor por defecto
    public Contador() {
    }
	
	//constructor
	public Contador (int cont) {
		if (cont<0) {
			this.cont=0;
		}else {
			this.cont = cont;
		}
	}
	
	//constructor copia
	public Contador (final Contador c) {
		cont = c.cont;
	}

	//getters y setters
	public double getCont() {
		return cont;
	}

	public void setCont(int cont) {
		if (cont<0) {
			this.cont=0;
		}else {
			this.cont = cont;
		}
	}
	
	//metodo incrementar
	public void incrementar () {
		cont++;
	}
	
	//metodo decrementar
	public void decrementar () {
		cont--;
		if (cont<0) {
			cont=0;
		}
	}
	
}
