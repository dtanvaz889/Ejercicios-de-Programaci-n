package ejercicio_03;
import java.util.Scanner;
public class mein {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new  Scanner (System.in);
		
		
		Contador contador_1 = new Contador();
		
		int num;
		System.out.println("Dime un valor para iniciar el contador: ");
		num = sc.nextInt();
		
		System.out.println("");
		System.out.println("CONTADOR 1:");
		System.out.println("");
		contador_1.setCont(num);
		System.out.print("Primer incremento (+1): ");
		contador_1.incrementar();
		
		System.out.println(contador_1.getCont());
		
		contador_1.incrementar();
		contador_1.incrementar();

		System.out.print("Segundo incremento (+2): ");
		System.out.println(contador_1.getCont());
		
		contador_1.decrementar();
		
		System.out.print("Primer decremento (-1): ");
		System.out.println(contador_1.getCont());
		
		System.out.println("");
		System.out.println("CONTADOR 2 (10):");
		System.out.println("");
		Contador contador_2 = new Contador(10);
		
		System.out.print("Primer incremento (+1): ");
		contador_2.incrementar();
		
		System.out.println(contador_2.getCont());
		
		System.out.print("Primer decremento (-1): ");
		contador_2.decrementar();
		
		System.out.println(contador_2.getCont());
		
		System.out.println("");
		System.out.println("CONTADOR 3 (copia del 2):");
		System.out.println("");
		Contador contador_3 = new Contador(contador_2);
		
		System.out.print("Valor: ");
		System.out.println(contador_3.getCont());
		
		
		sc.close();
	}

}
