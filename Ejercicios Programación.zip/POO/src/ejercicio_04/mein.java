package ejercicio_04;

import java.util.Scanner;

public class mein {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner sc = new Scanner(System.in);
		String titulo;
		String autor;
		int ejemplares;
		int ejemplares_prestados;
		
		Libro libro_1 = new Libro("Codigo da Vinci", "Dan Brown", 100, 32);   
		
		Libro libro_2 = new Libro();
		
		
		System.out.println("Dime el t�tulo de un libro: ");
		titulo = sc.nextLine();
		System.out.println("Dime su autor: ");
		autor = sc.nextLine();
		System.out.println("Dime cuantos ejemplares hay: ");
		ejemplares = sc.nextInt();
		System.out.println("Dime cuantos ejemplares prestados hay: ");
		ejemplares_prestados = sc.nextInt();
		
		libro_2.setTitulo_libro(titulo);
		libro_2.setAutor(autor);
		libro_2.setNum_ejemplares(ejemplares);
		libro_2.setNum_ejemplares_prestados(ejemplares_prestados);
		
		
		System.out.println("");
		System.out.println("LIBRO 1");
		System.out.println("");
		System.out.println("T�tulo: " + libro_1.getTitulo_libro());
		System.out.println("Autor: " + libro_1.getAutor());
		System.out.println("N�mero de ejemplares: " + libro_1.getNum_ejemplares());
		System.out.println("N�mero de libros prestados: " + libro_1.getNum_ejemplares_prestados());
		
		System.out.println("");
		System.out.println("LIBRO 2");
		System.out.println("");
		System.out.println("T�tulo: " + libro_2.getTitulo_libro());
		System.out.println("Autor: " + libro_2.getAutor());
		System.out.println("N�mero de ejemplares: " + libro_2.getNum_ejemplares());
		System.out.println("N�mero de libros prestados: " + libro_2.getNum_ejemplares_prestados());
		
		System.out.println("");
		System.out.println("Vamos a hacer un pr�stamo del libro 1");
		libro_1.prestamo();
		System.out.println("");
		System.out.println("LIBRO 1");
		System.out.println("");
		System.out.println("T�tulo: " + libro_1.getTitulo_libro());
		System.out.println("Autor: " + libro_1.getAutor());
		System.out.println("N�mero de ejemplares: " + libro_1.getNum_ejemplares());
		System.out.println("N�mero de libros prestados: " + libro_1.getNum_ejemplares_prestados());
		
		
		System.out.println("");
		System.out.println("Vamos a hacer dos devoluciones del libro 2");
		libro_2.devolucion();
		libro_2.devolucion();
		System.out.println("");
		System.out.println("LIBRO 2");
		System.out.println("");
		System.out.println("T�tulo: " + libro_2.getTitulo_libro());
		System.out.println("Autor: " + libro_2.getAutor());
		System.out.println("N�mero de ejemplares: " + libro_2.getNum_ejemplares());
		System.out.println("N�mero de libros prestados: " + libro_2.getNum_ejemplares_prestados());
		
		sc.close();
	}  
	

}
