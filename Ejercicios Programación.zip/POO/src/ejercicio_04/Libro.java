package ejercicio_04;

public class Libro {

	private String titulo_libro;
	private String autor;
	private int num_ejemplares;
	private int num_ejemplares_prestados;
	
	//constructor por defecto
	public Libro() {
		
	}
	
	//constructor
	public Libro(String titulo_libro, String autor, int num_ejemplares, int num_ejemplares_prestados) {
		this.titulo_libro=titulo_libro;
		this.autor=autor;
		this.num_ejemplares=num_ejemplares;
		this.num_ejemplares_prestados=num_ejemplares_prestados;
	}
	
	//constructor copia
	public Libro (final Libro c) {
		titulo_libro = c.titulo_libro;
		autor=c.autor;
		num_ejemplares=c.num_ejemplares;
		num_ejemplares=c.num_ejemplares_prestados;
	}

	//getters y setters
	public String getTitulo_libro() {
		return titulo_libro;
	}

	public void setTitulo_libro(String titulo_libro) {
		this.titulo_libro = titulo_libro;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public int getNum_ejemplares() {
		return num_ejemplares;
	}

	public void setNum_ejemplares(int num_ejemplares) {
		this.num_ejemplares = num_ejemplares;
	}

	public int getNum_ejemplares_prestados() {
		return num_ejemplares_prestados;
	}

	public void setNum_ejemplares_prestados(int num_ejemplares_prestados) {
		this.num_ejemplares_prestados = num_ejemplares_prestados;
	}
	
	public boolean prestamo() {
		
		boolean prestamo = true;
		
		if (num_ejemplares_prestados<num_ejemplares) {
			prestamo=true;

			num_ejemplares_prestados++;
			
		}else {
			prestamo=false;
		}
		
		return prestamo;
	}
		
	public boolean devolucion() {
		boolean devolucion = true;
		
		if ((num_ejemplares_prestados>0)) {
			devolucion=true;
			num_ejemplares_prestados--;
		}else {
			devolucion=false;
		}
		return devolucion;
		
	}
}
