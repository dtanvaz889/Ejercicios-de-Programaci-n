package examen_POO;

public class Vehiculos {
	
	private String marca;
	private String matricula;
	private int num_km;
	private int fecha_matriculacion;
	private String descripcion;
	private double precio;
	private String nombre_propietario;
	private String dni_propietario;

	
	//constructor por defecto (sin parametros)
	public Vehiculos() {
		
	}
	
	//constructor con parametros
	public Vehiculos (String marca, String matricula, int num_km, int fecha_matriculacion, String descripcion, double precio, String nombre_propietario, String dni_propietario) {
		this.marca=marca;
		this.matricula=matricula;
		this.num_km=num_km;
		this.fecha_matriculacion=fecha_matriculacion;
		this.descripcion=descripcion;
		this.precio=precio;
		this.nombre_propietario=nombre_propietario;
		this.dni_propietario=dni_propietario;
	}
	
	//constructor copia
	public Vehiculos (final Vehiculos c) {
		marca = c.marca;
		matricula=c.matricula;
		num_km=c.num_km;
		fecha_matriculacion=c.fecha_matriculacion;
		descripcion=c.descripcion;
		precio=c.precio;
		nombre_propietario=c.nombre_propietario;
		dni_propietario=c.dni_propietario;
	}

	//getters y setters
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public int getNum_km() {
		return num_km;
	}

	public void setNum_km(int num_km) {
		this.num_km = num_km;
	}

	public int getFecha_matriculacion() {
		return fecha_matriculacion;
	}

	public void setFecha_matriculacion(int fecha_matriculacion) {
		this.fecha_matriculacion = fecha_matriculacion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getNombre_propietario() {
		return nombre_propietario;
	}

	public void setNombre_propietario(String nombre_propietario) {
		this.nombre_propietario = nombre_propietario;
	}

	public String getDni_propietario() {
		return dni_propietario;
	}

	public void setDni_propietario(String dni_propietario) {
		this.dni_propietario = dni_propietario;
	}
	
	//metodo que devuelve los a�os de un veh�culo
	public int getAnios (int fecha_matriculacion) {
		
		int edad_coche;
		int fecha_1=2022;
		int fecha_2=fecha_matriculacion;
		
		
		edad_coche=(fecha_1-fecha_2);
		
		return edad_coche;
	}
	
}
