package examen_POO;

import java.util.Scanner;

public class Ejercicio3 {

  static int N = 50;
  
  public static void main(String[] args) {
	  
	  Scanner s=new Scanner(System.in);
		  

    //Crea el array de discos
   Vehiculos[] coche = new Vehiculos[N];

    // Crea todos los discos que van en cada una de
    // las celdas del array
    for(int i = 0; i < N; i++) {
      coche[i] = new Vehiculos();
    }

    int opcion;
    String matriculaIntroducida;
    String marcaIntroducida;
    int num_kmIntroducidos;
    int fecha_matriculacionIntroducida;
    String descripcionIntroducida;
    double precioIntroducido;
    String nombre_propietarioIntroducido;
    String dni_propietarioIntroducido;
    int primeraLibre;
    int i;
    
    do {
      imprimeCRUD();
      opcion = s.nextInt();
      
      switch (opcion) {
      case 1:
    	  System.out.println("\nNUEVO VEH�CULO");
	        System.out.println("==============");
	        
	        primeraLibre = -1;
	        do {
	          primeraLibre++;
	        } while (!((coche[primeraLibre].getMatricula()).equals(null))); {
	        				        
		        System.out.println("Por favor, introduzca los datos del veh�culo.");  
		        
		        System.out.print("Matr�cula: ");
		        s.nextLine();
		        matriculaIntroducida =s.nextLine();
		        coche[primeraLibre].setMatricula(matriculaIntroducida);
		        
		        System.out.print("Marca: ");
		        marcaIntroducida = s.nextLine();
		        coche[primeraLibre].setMarca(marcaIntroducida);
		        
		        System.out.print("N�mero de kilometros: ");
		        num_kmIntroducidos = s.nextInt();
		        coche[primeraLibre].setNum_km(num_kmIntroducidos);
		        
		        System.out.print("Fecha de matriculaci�n: ");
		        fecha_matriculacionIntroducida =s.nextInt();
		        coche[primeraLibre].setFecha_matriculacion(fecha_matriculacionIntroducida);
		       
		        System.out.print("Descripci�n: ");
		        descripcionIntroducida = s.nextLine();
		        coche[primeraLibre].setDescripcion(descripcionIntroducida);
		        
		        System.out.print("Precio: ");
		        precioIntroducido = s.nextDouble();
		        coche[primeraLibre].setPrecio(precioIntroducido);
		        
		        System.out.print("Nombre del propietario: ");
		        nombre_propietarioIntroducido = s.nextLine();
		        coche[primeraLibre].setNombre_propietario(nombre_propietarioIntroducido);
		        
		        System.out.print("DNI del propietario: ");
		        dni_propietarioIntroducido = s.nextLine();
		        coche[primeraLibre].setDni_propietario(dni_propietarioIntroducido);
		        }

	        break;
        
      case 2:
    	  System.out.println("\nLISTADO");
          System.out.println("=========");
          for(i = 0; i < N; i++) {
            if (!coche[i].getMatricula().equals("LIBRE")) {
              System.out.println(coche[i]);
            }
          }
          break;
        
      case 3:
        
        
      case 4:
    	  System.out.println("\nMODIFICAR KMS DE VEH�CULO");
          System.out.println("===========================");
          
          s.nextLine();
          System.out.print("Introduce la matr�cula del coche que deseas modificar: ");
          matriculaIntroducida =s.nextLine();
    
          i = -1;
          do {
            i++;
          } while (!((coche[i].getMatricula()).equals(matriculaIntroducida)));
          
          System.out.println("Dime el nuevo n�mero de kil�metros");
    
          System.out.println("Kil�metros: " + coche[i].getNum_km());
          System.out.print("Nuevo n�mero de kil�metros: ");
          num_kmIntroducidos = s.nextInt();
          
          
          }
          
          break;
    } while (opcion != 5);
    s.close();
  }
  
  public static void imprimeCRUD() {
	  System.out.println("\n\nCONCESIONARIO DE VEH�CULOS");
      System.out.println("==============================");
      System.out.println("1. Nuevo veh�culo");
      System.out.println("2. Listar veh�culos");
      System.out.println("3. Buscar veh�culos");
      System.out.println("4. Modificar kms de veh�culo");
      System.out.println("5. Salir");
      System.out.print("Introduzca una opci�n (n�mero): ");
  }
}