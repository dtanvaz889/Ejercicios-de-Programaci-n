package relacion_2;

/**
 * Bucles
 * 
 * 4. Muestra los n�meros del 320 al 160, contando de 20 en 20 hacia
 *    atr�s utilizando un bucle for.
 * 
 */

public class Ejercicio_04 {

  public static void main(String[] args) {
    
    for(int i = 320; i >= 160; i-=20) {
      System.out.println(i);
    }
  }
}