package relacion_2;

//Escribe un programa que permita ir introduciendo una serie indeterminada de n�meros mientras su suma no 
//supere el valor 10000. Cuando esto �ltimo ocurra, se debe mostrar el total acumulado, el contador de los 
//n�meros introducidos y la media.

import java.util.Scanner;

public class Ejercicio_23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sn=new Scanner(System.in);
		
		int suma=0;
		
		while(suma<=10000) {
			System.out.println("Dime un n�mero");
			int num=sn.nextInt();
			suma=num+suma;
		}
		
		System.out.println(suma);
		
		
		
		
		sn.close();
		
	}

}
