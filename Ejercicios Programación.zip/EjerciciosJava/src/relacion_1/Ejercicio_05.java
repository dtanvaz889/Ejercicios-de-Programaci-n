package relacion_1;

/**
*
* 5. Realiza un conversor de pesetas a euros. La cantidad en pesetas
*    que se quiere convertir deber� estar almacenada en una variable.
*
* 
*/


public class Ejercicio_05 {
 public static void main(String[] args) {
   int pesetas = 10000;
   double euros = pesetas / 166.386;
   
   System.out.println(pesetas + " pesetas son " + euros + " euros.");
   
 }
}
