package relacion_1;

/**
*
* 2. Crea la variable nombre y as�gnale tu nombre completo. Muestra su
*    valor por pantalla de tal forma que el resultado del programa sea
*    el mismo que en el ejercicio 1 del cap�tulo 1.
*
*/


public class Ejercicio_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nombre = "Daniel Tanco Vaz";
	    System.out.println(nombre);
	}

}
