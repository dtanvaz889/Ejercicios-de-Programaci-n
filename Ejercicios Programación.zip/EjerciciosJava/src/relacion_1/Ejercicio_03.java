package relacion_1;

/**
*
* 3. Crea las variables nombre, direccion y telefono y as�gnale los
*    valores correspondientes. Muestra los valores de esas variables
*    por pantalla de tal forma que el resultado del programa sea el
*    mismo que en el ejercicio 2 del cap�tulo 1.
*
*/



public class Ejercicio_03 {
	public static void main(String[] args) {
	String nombre = "Daniel Tanco Vaz";
   String direccion = "Cristo de la Sed, 82 - Sevilla";
   String telefono = "Tel: 666 12 34 56";
   System.out.println(nombre);
   System.out.println(direccion);
   System.out.println(telefono);

}
}
