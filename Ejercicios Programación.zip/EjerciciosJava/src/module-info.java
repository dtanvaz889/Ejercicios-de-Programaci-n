module ejerciciosJava {
}