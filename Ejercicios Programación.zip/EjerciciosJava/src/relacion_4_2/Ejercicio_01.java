package relacion_4_2;

public class Ejercicio_01 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	int [] [] num = new int[3][6];
	
	num [0] [0] = 0;
	
	num [0] [1] = 30;

	num [0] [2] = 2;
	
	num [0] [3] = 0;

	num [0] [5] = 5;

	num [1] [0] = 75;

	num [1] [4] = 0;

	num [2] [2] = -2;

	num [2] [3] = 9;
	
	num [2] [5] = 11;
	
	
	int fila, columna;
	
	System.out.println("|---------------------------------------------------------------------------------|");
	System.out.println("|Array num | Columna 0 | Columna 1 | Columna 2 | Columna 3 | Columna 4 | Columna 5|");
	System.out.println("|---------------------------------------------------------------------------------|");
	
	for(fila=0; fila<3; fila++) {
		
		System.out.print("|Fila: " + fila + "  ");
		
		
		for(columna=0; columna<6; columna++) {
			
			System.out.printf(" |   %2d     " , num[fila][columna] );
			
			
			   
		}
		System.out.println("|");
	
		System.out.println("|---------------------------------------------------------------------------------|");
		
		
	}
	

}
}