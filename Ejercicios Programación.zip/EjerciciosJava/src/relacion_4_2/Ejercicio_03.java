package relacion_4_2;

public class Ejercicio_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int [] [] num = new int[4][6];
		

		
		int fila=0, columna;
			
			
			for(columna=0; columna<6; columna++) {
				
				System.out.printf(" |   %2d     " , num[fila][columna] );
				
				for(fila=0; fila<3; fila++) {
					
					System.out.print("|Fila: " + fila + "  ");
				   
			}
			System.out.println("|");
		
			System.out.println("|---------------------------------------------------------------------------------|");
			
			
		}
			
			for(fila=0; fila<4; fila++) {
				
				System.out.print("|Fila: " + fila + "  ");
			   
		}
		System.out.println("|");
	
		System.out.println("|---------------------------------------------------------------------------------|");
		
		
		System.out.println("| Columna 0 | Columna 1 | Columna 2 | Columna 3 | Columna 4 | Columna 5 |  TOTAL  |");
		System.out.println("|---------------------------------------------------------------------------------|");
	}
	}
