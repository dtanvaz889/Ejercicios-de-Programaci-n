package bingo;

public class bingo_ale_s {
	//1� funcion para realizar la matriz de los cartones con el doble for.
			public static int[][] inicio_carton(){
				int carton[][];
			
				carton=new int[3][5];
				for( int i=0;i<5;i++) {
					for(int  j=0;j<3;j++) {
						carton[j][i]=0;
					}
				}
				return carton;
				

			}
		//2� funcion para a�adir valores a la matriz.
			public static int[][]rellenar_carton(){
				int carton[][];
				int i=0;
				int j=0;
				carton=new int[3][5];
				int cambionum;
				for(i=0;i<5;i++) {
					for(j=0;j<3;j++) {
						do{cambionum=((int) (Math.random()*9+1))+(i*10);
		 				  }while(repetidos(carton,cambionum)==false);
						carton[j][i]=cambionum;
					}
				}
				return carton;
			}
		//boolean para los numeros repetidos.
		private static boolean repetidos(int[][] carton, int cambionum) {
			 int i=0;
				 int j=0;
				 for ( i = 0; i<5; i++) {
					  for (j=0; j<3; j++) {
						  int numeros = 0;
						if (carton[j][i]==numeros) {
								 return false;
							 }
					  }
				  }
				 return true;
			 }
			 public static void visualizar_carton(int[][] carton) {
				 for(int i=0;i<3;i++) {
					 for(int j=0;j<5;j++) {
						 if (carton[i][j]==-1) {
		  					  System.out.print("XX");
						 
					 }else {
						 System.out.println(carton[i][j]+"");
					 }
						 if(carton[i][j]<10) {
							  System.out.print(" ");
						 }
						  System.out.print("|");
		   			 }
		   			  System.out.println("");
		   		  }
		   	 }
		 	 public static int[][] tachado_de_numeros(int[][] carton,int numeros){
		   		
		   		 int tachado[][];
		   		tachado=carton;
		   		 for (int i = 0; i<5; i++) {
		   			  for (int j=0; j<3; j++) {
		   				  if (tachado[j][i]==numeros) {
		   					  tachado[j][i]=-1;
		   					 }
		   			  }
		   		  }   		 
		   		 return tachado;
		   	 }
			 public static boolean comprobacion(int[][] carton){
		   	
		   		 for (int i = 0; i<5; i++) {
		   			  for (int j=0; j<3; j++) {
		   				  if (carton[j][i]!=-1) {
		   					  return false;
		   					 }
		   			  }
		   		  }
		   		 return true;
		   	 }
			//Comprobacion del premio de la l�nea (100�)
			 public static boolean comprobar_linea(int[][] carton){
		   		 boolean linea=true;
		   		 
		   		 for (int i = 0; i<3; i++) {
		   			 linea=true;   				 
		   			 for (int j=0; j<5; j++) {
		   				 if (carton[i][j]!=-1) {
		   					 linea=false;
		   				 }
		   			  }
		   			 if (linea) {
		   				 return true;
		   			 }
		   		  }
		   		 return false;
			 }
			 
			 public static void main(String[] args)     {
				 int premio_jugador_1=0;
		   		 int premio_jugador_2=0;
		   		 boolean sale_bola=false;
		   		 boolean termina_bucle;
		   		 boolean linea=false;
		   		 int arraybolas[];
		   		 arraybolas=new int[50];
		   		 for (int j=0; j<49; j++) {
		   			 arraybolas[j]= 0;
		   		  }
		   		 int primercarton[][];
		   		 int bola;
		   		 primercarton= new int [3][6];
		   		 primercarton = inicio_carton();
		   		 primercarton = rellenar_carton();
		   		System.out.println("Carton del 1� JUGADOR:");
		  		 System.out.println("---------------------------");
		  		 visualizar_carton(primercarton);
		  		 System.out.println(" ");
		  		 //Hacemos el mismo proceso con el segundo carton.
		  		 int segundocarton[][];
		  		 segundocarton = new int[3][6];
		  		 segundocarton = inicio_carton();
		   		 segundocarton = rellenar_carton();
		   		System.out.println("Carton del 2� JUGADOR:");
		 		 System.out.println("---------------------------");
		 		 visualizar_carton(segundocarton);
		 		 
		 		 //Sacar bola
		 		 do {
		   			 System.out.println(" ");
		   			 System.out.println("Pulsa cualquier tecla + INTRO para sacar bola:");
		   			 do {
		   				 bola=(int) (Math.random()*49+1);
		   				 sale_bola=false;
		   				termina_bucle=false;
		  				 int i=0;
		  				 while( i<50 && !termina_bucle) {
		  					 if (bola==arraybolas[i]) {
		  						 termina_bucle=true;
		  					 }
		  					 if(arraybolas[i]==0) {
		  						 arraybolas[i]=bola;
		  						 termina_bucle = true;
		  						 sale_bola=true;
		  					 }
		  					 i++;
		  				 }   		 
		  			 }while(!sale_bola);
		  			 System.out.println("> bola: " + bola);
		  			 System.out.println(" ");
		  			 primercarton= tachado_de_numeros(primercarton, bola);
		  			 segundocarton= tachado_de_numeros(segundocarton, bola);
		  			 System.out.println("Carton del 1� JUGADOR:");
		   			 System.out.println("----------------------------");
		   			 visualizar_carton(primercarton);
		   			 System.out.println(" ");
		   			 System.out.println("Carton del 2� JUGADOR:");
		   			 System.out.println("----------------------------");
		   			 visualizar_carton(segundocarton);
		   			 if (!comprobacion(primercarton)) {
		   				 if (!linea && comprobar_linea(primercarton)) {
		   					 premio_jugador_1+=100;
		   					 linea=true;
		   					 System.out.println("1� JUGADOR canta linea");
		   					 System.out.println(" ");
		   					 System.out.println("Dinero acumulado:");
		   					 System.out.println(premio_jugador_1);
		   					 System.out.println(premio_jugador_2);
		   				 }    
		 		 
			 }else {
					 System.out.println(" ");
					 System.out.println("1� JUGADOR canta Bingo!");
					 premio_jugador_1+=500;}
		   			if (!comprobacion(segundocarton)) {
		  				 if (!linea && comprobar_linea(segundocarton)) {
		  					 premio_jugador_2+=100;
		  					 linea=true;
		  					 System.out.println("2� JUGADOR canta linea");
		  					 System.out.println(" ");
		  					 System.out.println("Dinero acumulado:");
		  					 System.out.println(premio_jugador_1);
		  					 System.out.println(premio_jugador_2);
		  				 }
		} else {
				 System.out.println(" ");
				 System.out.println("2� JUGADOR canta Bingo!");
				 premio_jugador_2+=500;}
		 		} while (!comprobacion(primercarton) && !comprobacion(segundocarton));
		 		System.out.println(" ");
			   	  System.out.println("Dinero acumulado por Jugador1:");
			   	  System.out.println(premio_jugador_1);
			   	  System.out.println(" ");
			   	  System.out.println("Dinero acumulado por Jugador2:");
			   	  System.out.println(premio_jugador_2);
			   		 
			   	 }
			    
		}

