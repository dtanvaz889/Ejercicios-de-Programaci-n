package bingo;

/*Programa de juego de bingo para 2 jugadores con un carton para cada jugador en el que iran
saliendo bolas sin repetirse hasta que los jugadores completen el carton con sus nuemros.
Se contemplan dos premios en este juego:
1� para quien complete primero una linea de su carton (canta linea) con un premio acumulado de 100$
2� para quien complete el carton entero (canta bingo) con un premio acumulado de 500$
Los numeros del carton no se repetiran y las bolas que vayan saliendo tampoco*/

//import para la libreria io que nos proporciona la espera y pulsacion para que salga una bola nueva
import java.io.*;

public class BINGO_2 {

        //Funci�n para inicializar los cartones
        public static int[][] inicia_carton(){
             int carton[][];
             carton =new int[3][5];
             int i=0;
             int j=0;
            
             for ( i = 0; i<5; i++) {
                 for (j=0; j<3; j++) {
                     carton[j][i]= 0;
                 }
                
             }
             return carton;
            
        }
        
        
        // Funci�n para rellenar carton y a�adir valor a los cartones
        public static int[][] rellena_carton(){
             int carton[][];
             int cambio;
             carton =new int[3][5];
             int i=0;
             int j=0;
            
             for ( i = 0; i<5; i++) {
                 for (j=0; j<3; j++) {
                    
                     do {cambio=((int) (Math.random()*9+1))+(i*10);
                     }
                     while (comprobar_repetidos(carton,cambio)==false);
                     carton[j][i]= cambio;
                 }
             }
            
             return carton;
        }
        
        //funcion para imprimir los cartones por pantalla
        public static void imprime_carton(int[][] carton) {
            
            int i=0;
            int j=0;
            
             for ( i = 0; i<3; i++) {
                 for (j=0; j<5; j++) {
                     if (carton[i][j]==-1) {
                         System.out.print("X");
                     } else {
                         System.out.print(carton[i][j]+"");
                     }
                     if (carton[i][j]<10) {
                         System.out.print(" ");
                     }
                     System.out.print("|");
                }
                 System.out.println("");
             }
        }
        
        // Comprobaci�n de numeros repetidos
        public static boolean comprobar_repetidos(int[][] carton,int numero) {
            int i=0;
            int j=0;
            for ( i = 0; i<5; i++) {
                 for (j=0; j<3; j++) {
                     if (carton[j][i]==numero) {
                            return false;
                        }
                 }
             }
            return true;
        }
        
        //funci�n para tachar y comprobar los numeros con la bola sacada
        public static int[][] tacha_numero(int[][] carton,int numero){
            int i=0;
            int j=0;
            int carton_tachado[][];
            carton_tachado=carton;
            for ( i = 0; i<5; i++) {
                 for (j=0; j<3; j++) {
                     if (carton_tachado[j][i]==numero) {
                         carton_tachado[j][i]=-1;
                        }
                 }
             }            
            return carton_tachado;
        }
        
        //funci�n para comprobar si esta todo tachado
        public static boolean comprobar_tachado(int[][] carton){
            int i=0;
            int j=0;
            for ( i = 0; i<5; i++) {
                 for (j=0; j<3; j++) {
                     if (carton[j][i]!=-1) {
                         return false;
                        }
                 }
             }
            return true;
        }
            
        //funcion para comprobar el premio de las lineas
        public static boolean comprobar_premio_linea(int[][] carton){
            int i=0;
            int j=0;
            boolean linea_completa=true;
            
            for ( i = 0; i<3; i++) {
                linea_completa=true;                    
                for (j=0; j<5; j++) {
                    if (carton[i][j]!=-1) {
                        linea_completa=false;
                    }
                 }
                if (linea_completa) {
                    return true;
                }
             }
            return false;
        }

        
        public static void main(String[] args) throws IOException {
            // TODO Auto-generated method stub
            
            boolean ha_salido_linea=false;
            int premio_jugador1=0;
            int premio_jugador2=0;
            boolean ha_salido_bola=false;
            boolean termina_bucle;
            //bucle para inicializar el array de bolas que ya han salido
            int array_bolas[];
            array_bolas= new int[50];
            for (int j=0; j<49; j++) {
                array_bolas[j]= 0;
             }
            //declaraci�n de arrays para los cartones y primera impresion
            int carton1[][];
            int bola;
            
            carton1= new int [3][6];
            carton1 = inicia_carton();
            carton1 = rellena_carton();
            System.out.println("Carton del Jugador1:");
            System.out.println("--------------------");
            imprime_carton(carton1);
            System.out.println(" ");
            
            
            int carton2[][];
            carton2= new int [3][6];
            carton2 = inicia_carton();
            carton2 = rellena_carton();
            System.out.println("Carton del Jugador2:");
            System.out.println("--------------------");
            imprime_carton(carton2);
            
            
            //bucle para sacar bolas por pantalla, tachado de bola y comprobacion de linea & bingo
            do {
                System.out.println(" ");
                System.out.println("Pulsa una INTRO para sacar bola:");
                
                /*Pausa para tocar cualquier tecla y que salga la siguiente bola, he necesitado incluirlo dos
                veces para que se ejecute correctamente, de lo contrario mi laptop procesaba muy rapido la info y
                me sacaba dos bolas antes de hacer la pausa. He leido en foros que es un fallo de la consola de JAVA*/
                System.in.read();
                //System.in.read();
                
                //Bucle para sacar bolas
                do {
                    bola=(int) (Math.random()*49+1);
                    ha_salido_bola=false;
                    
                    //bucle para comprobar que no se repitan bolas sacadas
                    termina_bucle=false;
                    int i=0;
                    while( i<50 && !termina_bucle) {
                        if (bola==array_bolas[i]) {
                            termina_bucle=true;
                        }
                        if(array_bolas[i]==0) {
                            array_bolas[i]=bola;
                            termina_bucle=true;
                            ha_salido_bola=true;
                        }
                        i++;
                    }            
                }while(!ha_salido_bola);
                System.out.println("> bola: " + bola);
                System.out.println(" ");
                
                //Tachado de bola en carton e impresion de cartones comprobados
                carton1=tacha_numero(carton1, bola);
                carton2=tacha_numero(carton2, bola);
                System.out.println("Carton del Jugador1:");
                System.out.println("--------------------");
                imprime_carton(carton1);
                System.out.println(" ");
                System.out.println("Carton del Jugador2:");
                System.out.println("--------------------");
                imprime_carton(carton2);

                //comprobacion de (Linea si no se ha cantado) y de bingo en carton1
                if (!comprobar_tachado(carton1)) {
                    if (!ha_salido_linea && comprobar_premio_linea(carton1)) {
                        premio_jugador1+=100;
                        ha_salido_linea=true;
                        System.out.println("Jugador1 canta linea");
                        System.out.println(" ");
                        System.out.println("Dinero acumulado:");
                        System.out.println(premio_jugador1);
                        System.out.println(premio_jugador2);
                    }    
                } else {
                    System.out.println(" ");
                    System.out.println("Jugador1 canta Bingo!");
                    premio_jugador1+=500;}
                
                //comprobacion de Linea (si no se ha cantado) y de bingo en carton2
                if (!comprobar_tachado(carton2)) {
                    if (!ha_salido_linea && comprobar_premio_linea(carton2)) {
                        premio_jugador2+=100;
                        ha_salido_linea=true;
                        System.out.println("Jugador2 canta linea");
                        System.out.println(" ");
                        System.out.println("Dinero acumulado:");
                        System.out.println(premio_jugador1);
                        System.out.println(premio_jugador2);
                    }
                } else {
                    System.out.println(" ");
                    System.out.println("Jugador2 canta Bingo!");
                    premio_jugador2+=500;}
                
                } while (!comprobar_tachado(carton1) && !comprobar_tachado(carton2));
            
         System.out.println(" ");
         System.out.println("Dinero acumulado por Jugador1:");
         System.out.println(premio_jugador1);
         System.out.println(" ");
         System.out.println("Dinero acumulado por Jugador2:");
         System.out.println(premio_jugador2);
            
        }
    }



