package bingo;

import java.io.*;

public class bingo_completo {



/*Inicio la matiz del carton*/
   public static int [][] iniciar_matriz_carton(){

  int[][] matriz_carton = new int[3][5];

  for(int i=0; i<5;i++) {

  for(int j=0; j<3; j++) {
  matriz_carton[j][i]=0;
  }

  }

  return matriz_carton;

   }

/*Relleno el carton*/
   public static int[][] rellenar_matriz_carton(){

  int[][] matriz_carton = new int[3][5];
  int repetidos;

  for(int i=0; i<5;i++) {
 
  for(int j=0; j<3; j++) {
 
  do {repetidos=((int) (Math.random()*9+1))+(i*10);
  }

  while (comprobar_repetidos(matriz_carton,repetidos)==false);
  matriz_carton[j][i]=repetidos;
  }

  }

  return matriz_carton;

   }  



/*Compruebo los n�meros repetidos para que no vuelvan a salir*/
   public static boolean comprobar_repetidos(int[][] matriz_carton,int numero_bola) {

  for(int i=0; i<5;i++) {

  for(int j=0; j<3; j++) {

  if (matriz_carton[j][i]==numero_bola) {
  return false;
  }
 
  }

  }
 
  return true;
 
   }



/*Imprimo los cartones*/
public static void imprimir_carton(int[][] matriz_carton) {

for(int i=0; i<3;i++) {

for(int j=0; j<5; j++) {

if (matriz_carton[i][j]==-1) {
System.out.print("X");

}else {
System.out.print(matriz_carton[i][j]+"");
}

if (matriz_carton[i][j]<10) {
System.out.print(" ");
}

System.out.print("|");
}

System.out.println("");
}

}


/*Tacho el n�mero que ya ha salido en el carton*/
   public static int[][] tachar_carton(int[][] matriz_carton, int numero_bola){
   
  int numero_tachado[][] = matriz_carton;
   
   for ( int i = 0; i<5; i++) {
   
            for (int j=0; j<3; j++) {
           
                if (numero_tachado[j][i]==numero_bola) {
                    numero_tachado[j][i]=-1;
                }
            }
           
        }            
   
       return numero_tachado;
   }    
       
/*Comrpruebo lo que est� tachado con un booleano para que me devuelva un valor de "VERDADERO/FALSO"*/      
   public static boolean comprobar_numero_tachado(int[][] matriz_carton) {
 
  for(int i=0; i<5; i++) {
 
  for(int j=0; j<3; j++) {
 
  if (matriz_carton[j][i]!=-1) {
  return false;
  }
 
  }
 
  }
 
  return true;
   
   }    
   
   
/*Compruebo que las lineas se completan con un booleano para que me devuelva un valor de "VERDADERO/FALSO"*/
   public static boolean comprobar_linea_completa(int[][] matriz_carton) {
 
  boolean linea_completa=true;
 
  for (int i=0; i<3; i++) {
  linea_completa=true;
 
  for(int j=0; j<5; j++) {
               if (matriz_carton[i][j]!=-1) {
  linea_completa=false;
           }
  }
  if (linea_completa) {
  return true;
  }
  }
  return false;
   }
   
   
/*Algoritmo principal del juego*/
   public static void main(String[] args) throws IOException {
       // TODO Auto-generated method stub
       
 
/*Int necesarios*/
       int dinero_jugador_1=0;
       int dinero_jugador_2=0;

       
/*Booleans necesarios*/
       boolean bola=false;
       boolean linea=false;
       boolean fin;
       
       
/*Bucle de la matriz de las bolas*/
       int matriz_bolas[]=new int[50];
       
       for (int j=0; j<49; j++) {
           matriz_bolas[j]= 0;
       }
       
       
/*Imprimo el tablero y ejecuto las matrices de los cartones*/
       
       /*JUGADOR 1*/
       int carton_jugador_1[][];
       int numero_bola;
       
       carton_jugador_1=new int [3][6];
       
       carton_jugador_1=iniciar_matriz_carton();
       
       carton_jugador_1=rellenar_matriz_carton();
       
       System.out.println("�JUEGO DEL BINGO!");
       System.out.println(" ");
       System.out.println("PREMIOS: ");
       System.out.println("Cantar L�nea: 100�");
       System.out.println("Cantar Bingo: 500�");
       System.out.println(" ");
       System.out.println("*Si los jugadores cantan Bingo al mismo tiempo");
       System.out.println("se les dar� 500 a cada uno adem�s de");
       System.out.println("los 100 al primero que cantara l�nea");
       System.out.println(" ");
       System.out.println(" ");
       System.out.println("Carton del Jugador 1");
       System.out.println("--------------------");
       
       imprimir_carton(carton_jugador_1);

       System.out.println(" ");
       
       
       /*JUGADOR 2*/
       int carton_jugador_2[][];
       
       carton_jugador_2= new int [3][6];
       
       carton_jugador_2 = iniciar_matriz_carton();
       
       carton_jugador_2 = rellenar_matriz_carton();
       
       System.out.println("Carton del Jugador 2");
       System.out.println("--------------------");
       
       imprimir_carton(carton_jugador_2);
       
       System.out.println(" ");
       
       
       /*En este bucle se sacan las bolas por pantalla, se tachan los n�meros que han salido y se comprueban la linea y el bingo*/
       do {
           System.out.println(" ");
           System.out.println("Pulsa intro para sacar una bola:");
           
           
           /*Se incluye para que salgan las bolas de 1 en 1*/
           System.in.read();
           System.in.read();

           
           /*Bolas*/
           do {
               numero_bola=(int) (Math.random()*49+1);
               
               bola=false;
               fin=false;
               int i=0;
               
               while( i<50 && !fin) {
             
                   if (numero_bola==matriz_bolas[i]) {
                       fin=true;
                   }
                   
                   if(matriz_bolas[i]==0) {
                       matriz_bolas[i]=numero_bola;
                       fin=true;
                       bola=true;
                       
                   }
                   
                   i++;
                   
               }          
               
           }while(!bola);
            System.out.println("Nueva bola: " + numero_bola);
            System.out.println(" ");
            System.out.println(" ");

           
           /*Se ejecuta "tachar_carton" y se imprimen los cartones*/
           carton_jugador_1=tachar_carton(carton_jugador_1, numero_bola);
           carton_jugador_2=tachar_carton(carton_jugador_2, numero_bola);
           
           System.out.println("Carton del Jugador 1:");
           System.out.println("--------------------");
           
           imprimir_carton(carton_jugador_1);
           
           System.out.println(" ");
           System.out.println("Carton del Jugador 2:");
           System.out.println("--------------------");
           
           imprimir_carton(carton_jugador_2);

           /*Se comprueba SI "numero_tachado" y "linea completa"*/
           if (!comprobar_numero_tachado(carton_jugador_1)) {
         
               if (!linea && comprobar_linea_completa(carton_jugador_1)) {
                   dinero_jugador_1+=100;
                   linea=true;
                   
                   System.out.println(" ");
                   System.out.println("Jugador 1 canta linea");
                   System.out.println(" ");
                   System.out.print("Dinero acumulado Jugador 1:");
                   
                   System.out.println(dinero_jugador_1);
                   
                   System.out.print("Dinero acumulado Jugador 2:");

                   
                   System.out.println(dinero_jugador_2);
                   
               }    
               
           } else {
               System.out.println(" ");
               System.out.println("El Jugador 1 ha cantado Bingo!");
               
               dinero_jugador_1+=500;}
           
           /*Se comprueba SI NO "numero_tachado" y "linea completa"*/
           if (!comprobar_numero_tachado(carton_jugador_2)) {
         
               if (!linea && comprobar_linea_completa(carton_jugador_2)) {
                   dinero_jugador_2+=100;
                   linea=true;
                   
                   System.out.println(" ");
                   System.out.println("Jugador 2 canta linea");
                   System.out.println(" ");
                   System.out.print  ("Dinero acumulado:");
                   
                   System.out.println(dinero_jugador_1);
                   System.out.println(dinero_jugador_2);
                   
               }
               
           } else {
               System.out.println(" ");
               System.out.println("El Jugador 2 ha cantado Bingo!");
               
               dinero_jugador_2+=500;}
           
           } while (!comprobar_numero_tachado(carton_jugador_1) && !comprobar_numero_tachado(carton_jugador_2));
       
          System.out.println(" ");
  System.out.print("Dinero acumulado por el Jugador 1: ");
 
  System.out.println(dinero_jugador_1);
 
  System.out.println(" ");
  System.out.print("Dinero acumulado por el Jugador 2: ");
   }
}
 