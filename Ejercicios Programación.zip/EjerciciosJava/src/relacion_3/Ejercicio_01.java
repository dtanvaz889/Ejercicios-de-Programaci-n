package relacion_3;

public class Ejercicio_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num_min=1;
		int num_max=6;

		int num_aleatorio1=(int)Math.floor(Math.random()*(num_max-num_min)+num_min);
		int num_aleatorio2=(int)Math.floor(Math.random()*(num_max-num_min)+num_min);
		int num_aleatorio3=(int)Math.floor(Math.random()*(num_max-num_min)+num_min);
		
		System.out.println("Voy a hacer una tirada de tres dados y los voy a sumar");
		System.out.println(" ");
		System.out.println("Primera tirada: "+num_aleatorio1);
		System.out.println("Segunda tirada: "+num_aleatorio2);
		System.out.println("Tercera tirada: "+num_aleatorio3);

		int suma=(num_aleatorio1+num_aleatorio2+num_aleatorio3);
		
		System.out.println("Suma de las tiradas: "+suma);
	}

}
