package relacion_3;

public class Ejercicio_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num_max=9;
		int num_min=1;
		
		System.out.println("Voy a decir una carta al azar de la baraja espa�ola");
		
		int num_carta=(int)Math.floor(Math.random()*(num_max-num_min)+num_min);

		
		switch (numero_carta) {
		
		
		
			
		}
	}

}
