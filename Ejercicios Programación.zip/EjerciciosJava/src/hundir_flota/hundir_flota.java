package hundir_flota;

public class hundir_flota {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int [] [] num = new int[10][10];
		char [] letras = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'};
		
		System.out.println("REGISTRO DEL MAPA DEL ORDENADOR");
		System.out.println("");
		System.out.println("    [0] [1] [2] [3] [4] [5] [6] [7] [8] [9]");
		
		int fila, columna;
		
		for(fila=0; fila<10; fila++) {
			
			System.out.print("["+letras[fila]+"]");
			
			
			for(columna=0; columna<10; columna++) {
				
				System.out.print("  . ");
			}	
			System.out.println("");
		}

	}
}